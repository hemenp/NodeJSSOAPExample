# NodeJS SOAP XML API
<br />
 User modern web based programming languages to connect to soap api
<br />
<br />

# Usage:
<br />
<br />
1.) Navgiate to folder with Terminal on Mac or Powershell on Windows
<br />
2.) run "npm install" to get all of the nodejs dependencies from the package.json
<br />
3.) to launch web app run "node index.js" it will start on http://localhost:8000
